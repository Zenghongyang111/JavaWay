package dao;

import java.util.List;
import entity.Goods;

public interface GoodsDao {

	public List<Goods> Query(int typeid);
	
	public List<Goods> Search(String name);
}
