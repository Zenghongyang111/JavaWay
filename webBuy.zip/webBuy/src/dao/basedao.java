package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import entity.Goods;

public class basedao {
	 Connection con=null;
	   private static Context ctx=null;
	   public void closeAll(Connection con,Statement st,ResultSet rs){
			  if(rs!=null){
				  try {
		              rs.close();
		          } catch (Exception e) {
		              e.printStackTrace();
		          }
			  }
			  if (st != null) {
		          try {
		              st.close();
		          } catch (Exception e) {
		              e.printStackTrace();
		          }
		      }
			  if(con!=null){
				  try {
		              con.close();
		          } catch (Exception e) {
		              e.printStackTrace();
		          }
			  }
		  }
	   public static Context getContext(){
		  if(ctx==null){
		   try{
			   ctx=new InitialContext();
		   }catch(NamingException e){
			   e.printStackTrace();
			   throw new RuntimeException(e);
		   }
		  }
		  return ctx;
	   }
	   public Connection getConnection(){
		Connection conn=null;
		try{
			Context ctx=getContext();
			DataSource ds=(DataSource)ctx.lookup("java:comp/env/jdbc/mysql");
			conn=ds.getConnection();
		}catch(SQLException exception){
			exception.printStackTrace();
		}catch(NamingException e){
			e.printStackTrace();
		}
		   return conn;	   
	   }
	   public int excuteUpdate(String sql,Object[] param){
		    PreparedStatement pstmt = null;
			int num = 0;
			
			con= getConnection(); 
			try{
				pstmt=con.prepareStatement(sql);
				if(param!=null){
					for (int i = 0; i<param.length; i++){	
					   pstmt.setObject(i + 1, param[i]); 
				    }
			     }	 
				num=pstmt.executeUpdate();
			}catch(Exception e){
				e.printStackTrace();;
			}finally{
				closeAll(con,pstmt,null);
			}
			return num;
	   }
	   public int[] excuteUpdatelist(String sql,int id,List<Goods> list){
		    PreparedStatement pstmt = null;
			int[] num = {};
			
			con= getConnection(); 
			try{
				 pstmt=con.prepareStatement(sql);
       		   for(Goods g:list){      			       
					   Object[] param={id,g.getName(),g.getPrice()};
					for (int i = 0; i<param.length; i++){	
					   pstmt.setObject(i + 1, param[i]); 					  
				    }	
					   pstmt.addBatch();
				  }	
       		    num=pstmt.executeBatch();
			}catch(Exception e){
				e.printStackTrace();;
			}finally{
				closeAll(con,pstmt,null);
			}
			return num;
	   }
}
