package dao;

import java.util.List;

import entity.Goods;
import entity.Orderlist;

public interface Orderlistdao {

	public List<Orderlist> Query(int custom_id);
	
	public List<Goods> Querylist(int id);
	
	public int insertOrder(Orderlist order);
	
	public int getLastOrderid();
	
	public int[] insertOrderlist(int id ,List<Goods> list);
}
