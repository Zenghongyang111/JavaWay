package dao;

import entity.Customer;

public interface CustomDao {

	public Customer login(Customer cus);
	
	public int regist(String name,String pwd);
	
	public int getMoney(int id);
	
	public int changeMoney(int id,int money);
	
	
}
