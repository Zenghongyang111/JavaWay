package serviceimpl;

import java.util.List;

import dao.Orderlistdao;
import daoimpl.OrderlistDaoimpl;
import entity.Goods;
import entity.Orderlist;
import service.OrderlistService;

public class OrderlistServiceimpl implements OrderlistService{
     Orderlistdao dao=new OrderlistDaoimpl();
	@Override
	public List<Orderlist> Query(int custom_id) {
		
		return dao.Query(custom_id);
	}

	@Override
	public List<Goods> Querylist(int id) {
		
		return dao.Querylist(id);
	}

	@Override
	public int insertOrder(Orderlist order) {
		
		return dao.insertOrder(order);
	}

	@Override
	public int getLastOrderid() {
		// TODO Auto-generated method stub
		return dao.getLastOrderid();
	}

	@Override
	public int[] insertOrderlist(int id, List<Goods> list) {
		// TODO Auto-generated method stub
		return dao.insertOrderlist(id, list);
	}

}
