package serviceimpl;

import java.util.List;

import dao.GoodsDao;
import daoimpl.GoodsDaoimpl;
import entity.Goods;
import service.GoodsService;

public class GoodsServiceimpl implements GoodsService {
    GoodsDao dao=new GoodsDaoimpl();
	@Override
	public List<Goods> Query(int typeid) {
		// TODO Auto-generated method stub
		return dao.Query(typeid);
	}
	@Override
	public List<Goods> Search(String name) {
		// TODO Auto-generated method stub
		return dao.Search(name);
	}

}
