package serviceimpl;

import dao.CustomDao;
import daoimpl.CustomDaoimpl;
import entity.Customer;
import service.CustomerService;

public class CustomerServiceimpl implements CustomerService{
    CustomDao dao=new CustomDaoimpl();
	@Override
	public Customer login(Customer cus) {
		// TODO Auto-generated method stub
		return dao.login(cus);
	}
	@Override
	public int regist(String name, String pwd) {
		// TODO Auto-generated method stub
		return dao.regist(name, pwd);
	}
	@Override
	public int getMoney(int id) {
		// TODO Auto-generated method stub
		return dao.getMoney(id);
	}
	@Override
	public int changeMoney(int id, int money) {
		// TODO Auto-generated method stub
		return dao.changeMoney(id, money);
	}

}
