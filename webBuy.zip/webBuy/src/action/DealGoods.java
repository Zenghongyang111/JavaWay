package action;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import entity.Customer;
import entity.Goods;
import entity.Orderlist;
import service.CustomerService;
import service.GoodsService;
import service.OrderlistService;
import serviceimpl.CustomerServiceimpl;
import serviceimpl.GoodsServiceimpl;
import serviceimpl.OrderlistServiceimpl;

import com.alibaba.fastjson.JSON;
import com.sun.mail.iap.Response;

public class DealGoods extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public DealGoods() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		  String path=req.getContextPath();
		    String basePath=req.getScheme()+"://"+req.getServerName()+":"+req.getServerPort()+path+"/";
		    req.setCharacterEncoding("UTF-8");
		    resp.setHeader("Pragma", "No-cache");
			resp.setHeader("Cache-Control", "no-cache");
		    resp.setDateHeader("Expires", -10);
		    resp.setContentType("text/html);charset=UTF-8");
			String method=req.getParameter("action");
			PrintWriter out=resp.getWriter();
			OrderlistService os=new OrderlistServiceimpl();
			GoodsService gs=new GoodsServiceimpl();
			CustomerService cs=new CustomerServiceimpl();
			List<Goods> list=new ArrayList<Goods>();
			if("showGoods".equals(method)){
				int id=Integer.parseInt(req.getParameter("nid"));
				list=gs.Query(id);
				System.out.println(JSON.toJSONString(list));
				out.println(JSON.toJSONString(list));				
				out.flush();
				out.close();
			}else if("searchGoods".equals(method)){
				String name=req.getParameter("nname");
			    StringBuffer sb=new StringBuffer();
			    sb.append("%").append(name).append("%");
			    String s=sb.toString();
				List<Goods> list1=new ArrayList<Goods>();
				list1=gs.Search(s);
				System.out.println(JSON.toJSONString(list1));
                out.println(JSON.toJSONString(list1));		
				out.flush();
				out.close();
			}else if("loginin".equals(method)){		
				String name=req.getParameter("nname");
				String pwd=req.getParameter("npwd");
				Customer cus=new Customer();
				cus.setName(name);
				cus.setPwd(pwd);
				if(cs.login(cus)==null){
					resp.sendRedirect("/webBuy/login.jsp");
				}else{
					Customer cuss=new Customer();
					cuss=cs.login(cus);
					req.getSession().setAttribute("user", cuss);
					req.getRequestDispatcher("/mainShop.jsp").forward(req, resp);
				}
			}else if("register".equals(method)){
				String name=req.getParameter("nname");
				String pwd=req.getParameter("npwd");
				Customer cus=new Customer();
				cus.setName(name);
				cus.setPwd(pwd);
				cs.regist(name, pwd);
				Customer cuss=new Customer();
				cuss=cs.login(cus);
				req.getSession().setAttribute("user", cuss);
				req.getRequestDispatcher("/mainShop.jsp").forward(req, resp);
			}else if("loginout".equals(method)){
				req.getSession().setAttribute("user",null);
				req.getRequestDispatcher("/mainShop.jsp").forward(req, resp);
			}else if("buy".equals(method)){
				int id=Integer.parseInt(req.getParameter("cid"));
				System.out.println(id);
				List<Goods> goodslist=JSON.parseArray(req.getParameter("vals"), Goods.class);
                int totalprice=0;
                for(Goods g:goodslist){
                	System.out.println(g.getName());
                	totalprice+=g.getPrice();
                }
                Date date=new Date();
                SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                String date1=df.format(date);
                Orderlist order=new Orderlist();
                order.setCustomid(id);
                order.setTotalprice(totalprice);
                order.setOrderdate(date1);
                os.insertOrder(order);
                int orderid=os.getLastOrderid();
                os.insertOrderlist(orderid, goodslist);
			}else if("order".equals(method)){
				int id=Integer.parseInt(req.getParameter("nid"));
				List<Orderlist> list1=os.Query(id);
				out.println(JSON.toJSONString(list1));
				out.flush();
				out.close();
			}else if("ordershow".equals(method)){
				int id=Integer.parseInt(req.getParameter("nid"));
				List<Goods> list1=os.Querylist(id);
				out.println(JSON.toJSONString(list1));
				out.flush();
				out.close();
			}else if("deal".equals(method)){
				int id=Integer.parseInt(req.getParameter("cid"));
				int money=cs.getMoney(id);
				List<Goods> goodslist=JSON.parseArray(req.getParameter("vals"), Goods.class);
                int totalprice=0;
                for(Goods g:goodslist){
                	System.out.println(g.getName());
                	totalprice+=g.getPrice();
                }
                int reMoney=money-totalprice;
                if(reMoney>=0){
                	 cs.changeMoney(id, reMoney);
                	 Date date=new Date();
                     SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
                     String date1=df.format(date);
                     Orderlist order=new Orderlist();
                     order.setCustomid(id);
                     order.setTotalprice(totalprice);
                     order.setOrderdate(date1);
                     os.insertOrder(order);
                     int orderid=os.getLastOrderid();
                     os.insertOrderlist(orderid, goodslist);
                	out.println("�ۿ�ɹ��������ɶ���");
                	out.flush();
    				out.close();
                }else{
                	out.println("���㣬���ֵ��");
                	out.flush();
    				out.close();
                }
			}
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {

		req.setCharacterEncoding("UTF-8");
		 this.doGet(req, resp);
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
