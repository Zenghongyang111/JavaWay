package daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.GoodsDao;
import dao.basedao;
import entity.Goods;

public class GoodsDaoimpl extends basedao implements GoodsDao{

	@Override
	public List<Goods> Query(int typeid) {
		Connection con=this.getConnection();
	    PreparedStatement pstmt=null;
	    ResultSet rs=null;
	    List<Goods> list=new ArrayList<Goods>();
	    try{
	    	pstmt=con.prepareStatement("select * from shoplist where typeid=?");
	    	pstmt.setInt(1, typeid);
	    	rs=pstmt.executeQuery();
	    	while(rs.next()){
	    		Goods good=new Goods();
	    		good.setId(rs.getInt("id"));
	    		good.setTypeid(rs.getInt("typeid"));
	    		good.setName(rs.getString("name"));
	    		good.setPrice(rs.getInt("price"));
	    		list.add(good);
	    	}
	    }catch(SQLException e){
	    		e.printStackTrace();
	    }finally{
	    	this.closeAll(con, pstmt, rs);
	    }
		return list;
	}

	@Override
	public List<Goods> Search(String name) {
		Connection con=this.getConnection();
	    PreparedStatement pstmt=null;
	    ResultSet rs=null;
	    List<Goods> list=new ArrayList<Goods>();
	    try{
	    	pstmt=con.prepareStatement("select * from shoplist where name like ?");
	    	pstmt.setString(1, name);
	    	rs=pstmt.executeQuery();
	    	while(rs.next()){
	    		Goods good=new Goods();
	    		good.setId(rs.getInt("id"));
	    		good.setTypeid(rs.getInt("typeid"));
	    		good.setName(rs.getString("name"));
	    		good.setPrice(rs.getInt("price"));
	    		list.add(good);
	    	}
	    	
	    }catch(SQLException e){
	    		e.printStackTrace();
	    }finally{
	    	this.closeAll(con, pstmt, rs);
	    }
	    return list;
	}
		
}
