package daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.Orderlistdao;
import dao.basedao;
import entity.Goods;
import entity.Orderlist;

public class OrderlistDaoimpl extends basedao implements Orderlistdao{

	@Override
	public List<Orderlist> Query(int custom_id) {
		Connection con=this.getConnection();
	    PreparedStatement pstmt=null;
	    ResultSet rs=null;
	    List<Orderlist> list=new ArrayList<Orderlist>();
	    try{
	    	pstmt=con.prepareStatement("select * from orderlist where custom_id= ?");
	    	pstmt.setInt(1, custom_id);
	    	rs=pstmt.executeQuery();
	    	while(rs.next()){
	    		Orderlist or=new Orderlist();
	    		or.setId(rs.getInt("id"));
	    		or.setCustomid(rs.getInt("custom_id"));
	    		or.setOrderNo(rs.getString("orderNo"));
	    		or.setTotalprice(rs.getInt("totalprice"));
	    		or.setOrderdate(rs.getString("orderdate"));
	    		list.add(or);
	    	}
	    	
	    }catch(SQLException e){
	    		e.printStackTrace();
	    }finally{
	    	this.closeAll(con, pstmt, rs);
	    }
	    return list;
	}

	@Override
	public List<Goods> Querylist(int id) {
		Connection con=this.getConnection();
	    PreparedStatement pstmt=null;
	    ResultSet rs=null;
	    List<Goods> list=new ArrayList<Goods>();
	    try{
	    	pstmt=con.prepareStatement("select * from orderlist1 where orderlist_id= ?");
	    	pstmt.setInt(1, id);
	    	rs=pstmt.executeQuery();
	    	while(rs.next()){
	    		Goods good=new Goods();
	    		good.setName(rs.getString("name"));
	    		good.setPrice(rs.getInt("price"));
	    		list.add(good);
	    	}
	    	
	    }catch(SQLException e){
	    		e.printStackTrace();
	    }finally{
	    	this.closeAll(con, pstmt, rs);
	    }
	    return list;
	}

	@Override
	public int insertOrder(Orderlist order) {
		String sql="insert into orderlist(custom_id,orderNo,totalprice,orderdate) values(?,?,?,?)";
		Object[] param={order.getCustomid(),order.getOrderNo(),order.getTotalprice(),order.getOrderdate()};
		int num=this.excuteUpdate(sql, param);
		return num;
	}
    public int getLastOrderid(){
    	Connection con=this.getConnection();
	    PreparedStatement pstmt=null;
	    ResultSet rs=null;
	    int num=0;
	    try{
	    	pstmt=con.prepareStatement("select last_insert_id() as lastid");
	    	rs=pstmt.executeQuery();
	    	while(rs.next()){
	           num=(rs.getInt("lastid"));
	    	}
	    	   return num;	
           }catch(SQLException e){
		       e.printStackTrace();
           }finally{
	          this.closeAll(con, pstmt, rs);
          }
	    return num;
    }
	@Override
	public int[] insertOrderlist(int id, List<Goods> list) {
		
		String sql="insert into orderlist1(orderlist_id,name,price) values(?,?,?)";
		int[] num=this.excuteUpdatelist(sql, id, list);		
		return num;
	
	}

}
