package daoimpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import dao.CustomDao;
import dao.basedao;
import entity.Customer;


public class CustomDaoimpl extends basedao implements CustomDao{

	@Override
	public Customer login(Customer cus) {
		Connection con=this.getConnection();
	    PreparedStatement pstmt=null;
	    ResultSet rs=null;	  
	    try{
	    	pstmt=con.prepareStatement("select * from customer where name=? and pwd=?");
	    	pstmt.setString(1, cus.getName());
	    	pstmt.setString(2, cus.getPwd());
	    	rs=pstmt.executeQuery();
	    	while(rs.next()){
	    		Customer cuss=new Customer();
	    		cuss.setId(rs.getInt("id"));
	    		cuss.setName(rs.getString("name"));
	    		cuss.setPwd(rs.getString("pwd"));
	    		return cuss;
	    	}    	
	    }catch(SQLException e){
	    		e.printStackTrace();
	    }finally{
	    	this.closeAll(con, pstmt, rs);
	    }
		return null;
	}

	@Override
	public int regist(String name, String pwd) {
		String sql="insert into customer(name,pwd) values(?,?)";
		Object[] param={name,pwd};
		int num=this.excuteUpdate(sql, param);
		return num;
	}

	@Override
	public int getMoney(int id) {
		Connection con=this.getConnection();
	    PreparedStatement pstmt=null;
	    ResultSet rs=null;	
	    int money=0;
	    try{
	    	pstmt=con.prepareStatement("select money from customer where id=?");
	    	pstmt.setInt(1, id);    	
	    	rs=pstmt.executeQuery();
	    	while(rs.next()){
	    		money=rs.getInt("money");
	    		return money;
	    	}    	
	    }catch(SQLException e){
	    		e.printStackTrace();
	    }finally{
	    	this.closeAll(con, pstmt, rs);
	    }
		return money;
	}

	@Override
	public int changeMoney(int id, int money) {
		String sql="update customer set money=? where id=?";
		Object[] param={money,id};
		int num=this.excuteUpdate(sql, param);
		return num;
	}

}
