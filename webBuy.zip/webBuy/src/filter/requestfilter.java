package filter;
import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebInitParam;


@WebFilter(urlPatterns={"/*"},filterName="requestfilter",
initParams={@WebInitParam(name="charset",value ="utf-8")})
public class requestfilter implements Filter{
    private String charset=null;
	@Override
	public void destroy() {
		System.out.println("��������web�������ƻ�");
		
	}

	@Override
	public void doFilter(ServletRequest arg0, ServletResponse arg1,
			FilterChain arg2) throws IOException, ServletException {
		String path=((HttpServletRequest) arg0).getRequestURI();
		System.out.println("����"+path+"����AnnCharacterEncodingFilter");
		if(charset!=null){
			arg0.setCharacterEncoding(charset);
			arg1.setCharacterEncoding(charset);
		}
		arg2.doFilter(arg0, arg1);
		System.out.println("����"+path+"�˳�AnnCharacterEncodingFilter");
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		String initParam=arg0.getInitParameter("charset");
		if(initParam!=null && (initParam=initParam.trim()).length()!=0){
			System.out.println("��AnnCharacterEncodingFilter��charset����Ϊ"+initParam);
			charset=initParam;
		}
		
	}

}
