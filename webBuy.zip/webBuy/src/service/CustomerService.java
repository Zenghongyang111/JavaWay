package service;

import entity.Customer;

public interface CustomerService {

	public Customer login(Customer cus);
    
	public int regist(String name,String pwd);

	public int getMoney(int id);
	
	public int changeMoney(int id,int money);
}
